package com.salesianostriana.dam.repos;

import com.salesianostriana.dam.model.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepository extends JpaRepository<Profesor, Long> {
}
