package com.salesianostriana.dam.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Imparte {

    @Builder.Default
    // Aquí falta una anotación
    @EmbeddedId
    private ImpartePK id = new ImpartePK();// Aquí falta código


    @JsonIgnoreProperties("impartidos")
    @ManyToOne(fetch = FetchType.LAZY)
    // Aquí falta código
    @JoinColumn(name = "curso_id", foreignKey = @ForeignKey(name = "INMPARTE_CURSO"))
    private Curso curso;

    @JsonIgnoreProperties("impartidos")
    @ManyToOne(fetch = FetchType.LAZY)
    // Aquí falta código
    @JoinColumn(name = "profesor_id", foreignKey = @ForeignKey(name = "INMPARTE_PROFESOR"))
    private Profesor profesor;


    private String parte; // TEORÍA, PRÁCTICA

    private LocalDate fechaInicio, fechaFin;


    /* Aquí faltan dos métodos helpers */


    public void addToProfesor(Profesor p) {
        this.profesor = p;
        p.getImpartidos().add(this);
    }

    public void removeFromProfesor(Profesor p) {
        p.getImpartidos().remove(this);
        this.profesor = null;
    }

    public void addCurso(Curso c) {
        this.curso = c;
        c.getImpartidos().add(this);
    }

    public void removeFromCurso(Curso c){
        c.getImpartidos().remove(this);
        this.curso = null;
    }




}
