package com.salesianostriana.dam.repos;

import com.salesianostriana.dam.model.Imparte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImparteRepository extends JpaRepository<Imparte, Long> {
}
