package com.salesianostriana.dam.model;

import lombok.*;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.io.Serializable;


@Embeddable
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class ImpartePK implements Serializable {

    // Aquí falta una propiedad de la clase

    private Long profesor_id;

    // Aquí falta otra propiedad de la clase

    private Long curso_id;

    private int edicion; // Esta propiedad debe estar aquí y no se tiene que tocar




}
